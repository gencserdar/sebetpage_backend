package com.serdar.personal.model;

public enum Role {
    USER,
    ADMIN
}
